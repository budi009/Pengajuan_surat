<?php
        
			$style_kabupaten='class="form-control input-sm" id="dosen_id"';
echo form_dropdown("dosen_id",$dosenn,'',$style_kabupaten);
    ?>
