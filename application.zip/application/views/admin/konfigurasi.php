<!-- Surat Keterangan Aktif Kuliah -->

<!-- adminprodi/template/dashboard_header -->

<!-- sidebar menu -->
<!-- adminprodi/template/dasboard_side -->
<!-- /sidebar menu -->

<!-- top navigation -->
<!-- adminprodi/template/dasboard_top -->
<!-- /top navigation -->

<!-- page content -->
<!-- <div class="right_col" role="main"> -->

<!-- page content -->
<div class="right_col" role="main">
  <div class="">
    <div class="page-title">
      <div class="title_left">
        <h3>Surat Keterangan Aktif Kuliah</h3>
      </div>


    </div>
    <div class="clearfix"></div>
    <div class="row">
      <div class="col-md-12 col-sm-12 ">
        <div class="x_panel">
          <div class="x_title">
            <h2>DATA MAHASISWA</h2>
            <div class="clearfix"></div>
          </div>
          <div class="x_content">
            <div>
              <span style="color: red; font-size: 16px;">
                *) Wajib diisi
              </span>
            </div>
            <br />
            <?php echo form_open_multipart('user/surat1'); ?>


            <div class="form-group row">
              <label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name"> Nama Lengkap <span style="color: red;" class="required">*</span>
              </label>
              <div class="col-md-6 col-sm-6 ">
                <input type="hidden" id="nama" name="nama" value="<?= $user['nama_user']; ?>" required="required" class="form-control ">
                <input type="text" disabled id="nama" name="nama" value="<?= $user['nama_user']; ?>" required="required" class="form-control ">
              </div>
            </div>
            


            <div class="ln_solid"></div>

           
           
            <br>
            <br>
            <div class="ln_solid"></div>
            <div class="item form-group">
              <div class="col-md-6 col-sm-6 offset-md-5">
                <button type="submit" class="btn btn-success">Submit</button>
              </div>
            </div>
            <?php echo form_close(); ?>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- /top tiles -->
<!-- </div> -->

<!-- adminprodi/template/dashboard_footer -->