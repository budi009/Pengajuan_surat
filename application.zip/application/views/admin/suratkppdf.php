<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiva="X-UA-Compatible" content="IE=edge">

    <title>Cetak Surat</title>

    <link rel="stylesheet" href="">

    <style>
        .line-title {
            border: 0;
            border-style: inset;
            border-top: 1px solid #000;
        }
    </style>

</head>

<body>
    <img src="assets/img/logopoliwangi.png" style="position: absolute" ; width="100px" height="auto">
    <table style="width: 100%;">
        <tr>
            <td align="center">
                <span style="line-height: 1.1; font-weight: bold; font-family: 'Times New Roman', Times, serif">
                    KEMENTERIAN RISET, TEKNOLOGI DAN PENDIDIKAN TINGGI<br>
                    POLITEKNIK NEGERI BANYUWANGI<br>
                    <a style="line-height: 1.1; font-size: 11px"> Jl. Raya Jember KM 13 Labanasem, Kabat, Banyuwangi, 68461 </a> <br>
                    <a style="line-height: 1.1; font-size: 11px"> Telepon / Faks : (0333) 636780 </a> <br>
                    <a style="line-height: 1.1; font-size: 11px"> E-mail : poliwangi@poliwangi.ac.id ; Website : http://www.poliwangi.ac.id </a> <br>
                </span>
            </td>
        </tr>
    </table>
    <hr class="line-title">

    <p style="margin-left: 50px; margin-right: 50px; text-align: justify;">
           <?php foreach($datas as $data) { 
               
            ?>
            <span style="margin-left: 10px;">
                <a style="margin-right: 40px; font-size: 12;" >Nomor</a> : <?php echo $data->nomor_surat ?> /PL36/PK.01.06/2019 <a style="font-size: 12;margin-left: 125px;">Banyuwangi,</a>
            </span> <br>
            <span style="margin-left: 10px; ">
                <a style="margin-right: 23px;font-size: 12;">Lampiran</a> :
            </span> <br>
            <span style="margin-left: 10px;">
                <a style="margin-right: 40px;font-size: 12;">Perihal</a> : <a style="font-size: 12;">Izin Lokasi Kerja Praktek</a>
            </span>
        </p>
        <br>
        <br>
    <p style="margin-left: 50px; margin-right: 50px; text-align: justify;">
           
            <span style="margin-left: 10px;">
                <a style="margin-right: 5px; font-size: 12;" >Kepada Yth </a> :
            </span> <br>
            <span style="margin-left: 10px; ">
                <b style="margin-right: 23px;font-size: 12;">Pimpinan <?php echo $data->tempat ?></b> 
            </span> <br>
            <span style="margin-left: 10px;">
                <a style="margin-right: 40px;font-size: 12;"><?php echo $data->alamat_tempat ?></a> 
            </span>
        </p>

        <p style="margin-left: 50px; margin-right: 50px; text-align: justify;">
            <br style="line-height: 1;">
        </p>
        <?php foreach($datas2 as $data2) { ?>
            <?php if ($data2->kp_id == $data->id_kp) { ?>
               

            <?php echo $data2->nama ?></b><br>

           
           <?php }?>
           <?php }?>
           <?php }?>